/* File: common.h
 Author: Will Smart, 2004

 Description: Some specializations of internal types for gpp for classification as featured here
*/

