The package of ECJ is applied in this problem.
The program code is mainly modified from MultiValuedRegression.java in the following directory: 
/ecj/ec/app/tutorial4
There are two added functions realized by Div.java and RegERC.java in the directory.
The parameters are set in ass2_2.params.
In order to read trees easier, ECJ offers C-ish format.
Run the command as follow:
java ec.Evolve -file ass2_2.params -p gp.tree.print-style=c