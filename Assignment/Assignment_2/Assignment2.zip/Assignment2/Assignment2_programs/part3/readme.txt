The package of ECJ is applied in this problem.
The program code is mainly modified from Benchmarks.java in the following directory: 
/ecj/ec/app/regression
There are five added functions realized by Abs.java, X6.java, X7.java, X8.java�� X9.java in the func directory.
The parameters are set in ass2_3.params.
In order to read trees easier, ECJ offers C-ish format.
Run the command as follow:
java ec.Evolve -file ass2_3.params -p gp.tree.print-style=c