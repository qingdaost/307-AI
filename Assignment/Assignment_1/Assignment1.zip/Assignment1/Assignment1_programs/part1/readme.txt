KNN.py is for COMP307 assignment 1 Part 1: Nearest Neighbour Method, programmed by Python.
KM.py is for COMP307 assignment 1 Part 1 optional question: K-Means Clustering, programmed by Python.
Run them directly in any Python IDE.