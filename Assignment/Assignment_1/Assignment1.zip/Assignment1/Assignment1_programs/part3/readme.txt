Perceptron.py is for COMP307 assignment 1 Part 3: Perceptron, programmed by Python.
test0.data, test1.data and test2.data are created by MakeImage.jav as test data for evaluating the perceptron��s performance.
Run it directly in any Python IDE.