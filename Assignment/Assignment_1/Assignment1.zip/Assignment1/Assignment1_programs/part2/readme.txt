DT.py is for COMP307 assignment 1 Part 2: Decision Tree Learning Method, programmed by Python.
Run it directly in any Python IDE.